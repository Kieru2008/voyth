import './css/RgbDivider.css';

const Divider = () => {
	return (
		<div className='custom-shape-rgbdivider'>
			<div className='relative gradient-background w-full h-44 -z-10'>
			</div>
		</div>
	);
};

export default Divider;
