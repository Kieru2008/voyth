import './css/Divider.css';

const Divider = () => {
	return <div className='custom-shape-divider '></div>;
};

export default Divider;
